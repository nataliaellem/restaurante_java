public class Restaurante {
    public static void main(String[] args) {

        MenuConsole m = new MenuConsole();
        m.iniciar();

    }
}
